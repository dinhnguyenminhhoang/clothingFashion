import ArrowRightLong from "./ArrowRightLong";
import SliderNextBtn from "./SliderNextBtn";
import SliderPrevBtn from "./SliderPrevBtn";
import TextShape from "./TextShape";
import Email from "./Email";
import Location from "./Location";
export {
  ArrowRightLong,
  SliderNextBtn,
  SliderPrevBtn,
  TextShape,
  Email,
  Location,
};
